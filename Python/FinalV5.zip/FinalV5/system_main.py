import thread
import time
import XBee_Threaded
import datetime

from change_room_device_port import ChangeRoomDevicePort
from change_room_device_status import ChangeRoomDeviceStatus
from send_room_schedule import SendRoomSchedules

from SQL_class import SQLClass

sql = SQLClass()
xbee = XBee_Threaded.XBee("/dev/ttyUSB0")

while True:
	msg = xbee.Receive()
	if msg and msg[14]==2:
		now = datetime.datetime.now()

		hour = ConvertIntToHex(now.strftime("%H"))
		minute = ConvertIntToHex(now.strftime("%M"))
		second = ConvertIntToHex(now.strftime("%S"))
		day = ConvertIntToHex(now.strftime("%d"))
		month = ConvertIntToHex(now.strftime("%m"))
		year = int(now.strftime("%Y"))

		date_time_data = "03 {} {} {} {} {} {} {}".format(
			hour,
			minute,
			second,
			day,
			month,
			ConvertIntToHex((year >> 8) & 0xFF),
			ConvertIntToHex(year & 0xFF)
			)

		addr = ""
		for byte_data in msg[3:11]:
			addr = "{} {}".format(addr, ConvertIntToHex(byte_data))

		date_time_data = "2E {} {}".format(ConvertIntToHex(len(bytearray.fromhex(date_time_data))), date_time_data)
		xbee.Send(bytearray.fromhex(date_time_data), addr)

	sql.GetQuery("triggers")
	triggers_result = sql.FetchAll()

	for trigger in triggers_result:
		if trigger[2]==1:
			thread.start_new_thread(ChangeRoomDevicePort, (trigger[1], ))
		elif trigger[2]==2:
			sql.GetWhereQuery("room_schedules", "room_schedules_id={}".format(trigger[1]))
			sql.SelectColumn("rooms_id")
			room_schedules_result = sql.FetchOne()

			thread.start_new_thread(SendRoomSchedules, (room_schedules_result[0], trigger[1], ))
		elif trigger[2]==3:
			thread.start_new_thread(SendRoomSchedules, (trigger[1],))
		elif trigger[2]==4:
			break;
		elif trigger[2]==5:
			thread.start_new_thread(ChangeRoomDeviceStatus, (trigger[1],))

		sql.DeleteQuery("triggers", "triggers_id={}".format(trigger[0]))
		sql.Commit()