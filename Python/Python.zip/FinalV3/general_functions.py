def ConvertIntToHex(value):
	return hex(int(value))[2:].zfill(2)